from app import app
from database import db

# 初始化应用和数据库
with app.app_context():
    db.create_all() 