# database package
from flask_sqlalchemy import SQLAlchemy

# 创建数据库实例
db = SQLAlchemy() 